import java.util.ArrayList;

public class Agenda {
    private ArrayList<Contato> contatos;

    public Agenda() {
        contatos = new ArrayList<>();
    }

    public void addContato(Contato c) {
        contatos.add(c);
    }

    public void removerContato(String info) {
        for (Contato c : contatos) {
            if (c.buscarContato(info)) {
                contatos.remove(c);
            } else {
                System.out.println("Contato não existe.");
            }
        }
    }

    public void visualizarContatos() {
        System.out.println("#### TODOS OS CONTATOS ####");
        for (Contato x : contatos) {
            System.out.println(x);
        }
    }
}